<?php

    include('html/doctype.html');

?>

 <body>

<?php
     include('html/formulaire.html');
?>


<!-- Bundle Bootstrap --------------------------------- -->
<script type="text/javascript" src="../../bundle.js"></script>
   
</body>
</html>


