document.addEventListener("DOMContentLoaded", function(event) {

    document.querySelector("#annuler")
        .addEventListener("click", function() {
        location = "../../index.php";
    })
})

