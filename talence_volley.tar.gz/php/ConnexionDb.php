<?php

    
    define("MYSQL","mysql:host=localhost;dbname=talence_volley");
    define("USER","root");
    define("PSWD","jordan");

?>