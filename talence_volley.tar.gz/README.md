# ajax_exemple

NodeJs utilisé comme manager de paquets pour bootstrap, jquery, popper.js
Browserify app.js -> bundle.js

Fonctionnement du site en PHP pour les requêtes BDD Mysql

Requêtes AJAX pour la mise de la bdd

Pas de framework Front End
